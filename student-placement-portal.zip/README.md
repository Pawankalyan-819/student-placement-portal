
# Student Placement Portal

A full-stack web application for managing student job applications and campus placement activities.

## 👨‍💻 Tech Stack
- Spring Boot (Java)
- MySQL
- HTML + CSS

## ✨ Features
- Student Registration/Login
- View & Apply to Jobs
- Admin Dashboard for Job Posting
- Application Tracker

## 🔌 How to Run
1. Import the Spring Boot project in your IDE.
2. Configure `application.properties` with your MySQL DB.
3. Create tables using `schema.sql`.
4. Open `index.html` in browser for frontend.

## 📂 Author
Pawan Kalyan Vemuri
